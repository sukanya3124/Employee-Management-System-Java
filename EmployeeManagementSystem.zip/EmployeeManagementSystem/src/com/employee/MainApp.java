package com.employee;

import java.util.List;

public class MainApp {

    public static void main(String[] args) {

        DBConnection.connect();

        EmployeeDAO dao = new EmployeeDAOImpl();

        Employee e1 = new Employee(1, "Sukanya", "IT", 25000);
        Employee e2 = new Employee(2, "Ravi", "HR", 20000);

        dao.addEmployee(e1);
        dao.addEmployee(e2);

        List<Employee> employees = dao.getAllEmployees();

        System.out.println("Employee Details:");
        for (Employee emp : employees) {
            System.out.println(
                emp.getId() + " | " +
                emp.getName() + " | " +
                emp.getDepartment() + " | " +
                emp.getSalary()
            );
        }
    }
}