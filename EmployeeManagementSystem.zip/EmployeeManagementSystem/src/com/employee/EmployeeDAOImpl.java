package com.employee;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDAOImpl implements EmployeeDAO {

    private List<Employee> employeeList = new ArrayList<>();

    @Override
    public void addEmployee(Employee emp) {
        employeeList.add(emp);
        System.out.println("Employee added successfully!");
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeList;
    }
}
