package com.employee;

import java.util.List;

public interface EmployeeDAO {
    void addEmployee(Employee emp);
    List<Employee> getAllEmployees();
}
