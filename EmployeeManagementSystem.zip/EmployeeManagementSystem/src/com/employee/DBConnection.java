package com.employee;

public class DBConnection {

    public static void connect() {
        System.out.println("Database connected successfully (Mock Connection)");
    }
}
